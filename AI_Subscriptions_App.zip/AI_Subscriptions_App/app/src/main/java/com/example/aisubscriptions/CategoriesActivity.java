package com.example.aisubscriptions;import android.os.*;import android.view.*;import android.widget.*;import android.graphics.*;
public class CategoriesActivity extends Base{ public void onCreate(android.os.Bundle b){super.onCreate(b); LinearLayout r=root(); setContentView(r); r.addView(tv("الفئات  →",22,Color.BLACK,Typeface.BOLD)); String[] cats={"المحادثة والكتابة
ChatGPT - Claude - Gemini 💬","تصميم الصور والفيديو
Midjourney - Leonardo - Runway 🖼","البرمجة والتطوير
GitHub Copilot - Replit </>","الأعمال والإنتاجية
Microsoft 365 - Notion - Canva 💼","الأدوات التعليمية
QuillBot - Grammarly 🎓"}; for(String c:cats){ TextView v=tv(c,16,Color.DKGRAY,Typeface.BOLD); v.setBackgroundResource(R.drawable.card); r.addView(v,new LinearLayout.LayoutParams(-1,90)); } nav(r,4); }}
