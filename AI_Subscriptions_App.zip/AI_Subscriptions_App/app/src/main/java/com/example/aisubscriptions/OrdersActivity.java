package com.example.aisubscriptions;import android.os.*;import android.view.*;import android.widget.*;import android.graphics.*;
public class OrdersActivity extends Base{ public void onCreate(android.os.Bundle b){super.onCreate(b); LinearLayout r=root(); setContentView(r); r.addView(tv("طلباتي  →",22,Color.BLACK,Typeface.BOLD)); String[] st={"نشط","نشط","منتهي"}; for(int i=0;i<3;i++){ TextView v=tv(st[i]+"     "+names[i]+"
شهر واحد
"+prices[i]+" جنيه سوداني",17,Color.BLACK,Typeface.BOLD); v.setBackgroundResource(R.drawable.card); r.addView(v,new LinearLayout.LayoutParams(-1,120)); } nav(r,1); }}
