package com.example.aisubscriptions;
import android.app.*;import android.content.*;import android.view.*;import android.widget.*;import android.graphics.Color;import android.graphics.Typeface;import android.os.*;import java.util.*;
public class Base extends Activity{
 int green=Color.rgb(0,185,120), blue=Color.rgb(39,88,255); String[] names={"ChatGPT Plus","Claude Pro","Gemini Advanced","Midjourney Standard","Canva Pro","Microsoft 365 Personal"}; int[] prices={7500,8000,7000,6000,3000,5000};
 TextView tv(String t,int sp,int c,int style){ TextView v=new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(c); v.setTypeface(Typeface.DEFAULT,style); v.setGravity(Gravity.CENTER); return v; }
 TextView btn(String t){ TextView v=tv(t,18,Color.WHITE,Typeface.BOLD); v.setBackgroundResource(com.example.aisubscriptions.R.drawable.btn_green); v.setPadding(14,14,14,14); return v; }
 LinearLayout root(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(22,22,22,22); l.setBackgroundColor(Color.rgb(246,247,252)); return l; }
 void nav(LinearLayout r,int active){ LinearLayout n=new LinearLayout(this); n.setGravity(Gravity.CENTER); n.setPadding(0,10,0,0); String[] s={"حسابي","طلباتي","الرئيسية","المفضلة","الفئات"}; Class[] cs={MainActivity.class,OrdersActivity.class,MainActivity.class,MainActivity.class,CategoriesActivity.class}; for(int i=0;i<s.length;i++){ TextView b=tv(s[i],13,i==active?blue:Color.DKGRAY,Typeface.BOLD); b.setText((i==active?"●
":"○
")+s[i]); b.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1)); final int k=i; b.setOnClickListener(v->startActivity(new Intent(this,cs[k]))); n.addView(b);} r.addView(n); }
}
