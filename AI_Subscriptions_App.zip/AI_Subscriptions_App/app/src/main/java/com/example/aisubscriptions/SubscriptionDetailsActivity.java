package com.example.aisubscriptions;import android.os.*;import android.content.*;import android.view.*;import android.widget.*;import android.graphics.*;
public class SubscriptionDetailsActivity extends Base{ public void onCreate(Bundle b){super.onCreate(b); int i=getIntent().getIntExtra("i",0); LinearLayout r=root(); setContentView(r); r.setBackgroundResource(R.drawable.bg_splash); r.addView(tv("تفاصيل الاشتراك  ♡",22,Color.WHITE,Typeface.BOLD)); r.addView(tv("▣
"+names[i],28,Color.WHITE,Typeface.BOLD)); TextView f=tv("المميزات
✓ الوصول إلى GPT-4o
✓ سرعة أعلى في الاستجابة
✓ أولوية في أوقات الذروة
✓ رفع الملفات والصور
✓ تحليل البيانات المتقدمة",16,Color.BLACK,Typeface.BOLD); f.setBackgroundResource(R.drawable.card); r.addView(f,new LinearLayout.LayoutParams(-1,230)); r.addView(tv("مدة الاشتراك",18,Color.WHITE,Typeface.BOLD)); r.addView(tv("شهر     3 أشهر     سنة",16,Color.WHITE,Typeface.BOLD)); r.addView(tv("السعر
"+prices[i]+" جنيه سوداني",26,Color.WHITE,Typeface.BOLD)); TextView buy=btn("اشترك الآن 🛒"); buy.setOnClickListener(v->startActivity(new Intent(this,CheckoutActivity.class).putExtra("i",i))); r.addView(buy,new LinearLayout.LayoutParams(-1,60)); r.addView(tv("✓ تفعيل فوري    ✓ ضمان كامل    ✓ دعم 24/7",14,0xffddfff4,Typeface.BOLD)); }}
